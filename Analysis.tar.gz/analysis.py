import pandas as pd
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', 8)

def genderfy(n):
    male = ('male', 'man')
    female = ('female', 'woman')
    if n in male:
        return 'm'
    elif n in female:
        return 'f'
    else:
        return 'f'


# Load csv
general = pd.read_csv('general.csv')
prenatal = pd.read_csv('prenatal.csv')
sports = pd.read_csv('sports.csv')

# Preprocess
prenatal.rename(columns={'HOSPITAL': 'hospital'}, inplace=True)
prenatal.rename(columns={'Sex': 'gender'}, inplace=True)
sports.rename(columns={'Hospital': 'hospital'}, inplace=True)
sports.rename(columns={'Male/female': 'gender'}, inplace=True)

# Merge
merge1 = pd.concat([general, prenatal], ignore_index=True)
merge2 = pd.concat([merge1, sports], ignore_index=True)

# Drop not necessary
merge2.drop(['Unnamed: 0'], axis=1, inplace=True)
merge2.dropna(how='all', inplace=True, axis=0)

# Gender replace
merge2['gender'] = merge2['gender'].apply(lambda x: genderfy(x))
# fill na
merge2.fillna(0, axis=0, inplace=True)
#print(merge2.loc[500 : 800, 'hospital':'blood_test'])

# Questions
# 1. Hospital with most patients
q1 = merge2.copy().groupby(['hospital'])['hospital'].count()
#print('The answer to the 1st question is ', q1.idxmax())
# 2. Stomach issues
q2 = len(merge2.copy().query("hospital == 'general' & diagnosis == 'stomach'"))
g2_patients = len(merge2.copy().query("hospital == 'general'").index)
#print('The answer to the 1st question is ', round(q2 / g2_patients, 3))
# 3. Dislocation issues
q3 = merge2.copy().query("hospital == 'sports' & diagnosis == 'dislocation'")
g3_patients = len(merge2.copy().query("hospital == 'sports'").index)
#print('The answer to the 1st question is ', round(len(q3.index) / g3_patients, 3))
# 4. dif mean gen and sport
q4 = merge2.copy().groupby(['hospital'])['age'].median(numeric_only=True)
#print('The answer to the 1st question is ', round(q4.loc[['general']][0] - q4.loc[['sports']][0], 3))
# 5. most often blood test hospital
q5 = merge2.copy().query("blood_test == 't'").groupby('hospital')['blood_test'].count()
#print('The answer to the 1st question is ', q5.idxmax(), ', ', q5.max(), ' blood tests')

# Visualize it!

bins = [0, 15, 35, 55, 70, 80]
data_hist = merge2['age']
bins_range = ['0-15', '15-35', '35-55', '55-70', '70-80']
# Create figure and plot:
plt.hist(data_hist, bins=bins, alpha=0.9, label='Value', edgecolor='Blue', linewidth=2)

# Set x and y labels
plt.ylabel("Freq")
plt.xlabel("Range of ages")
plt.title('Age distribution')

# Save and close
plt.savefig('first.png')
plt.show()
plt.close()
print('The answer to the 1st question: 15-35')

# Second question PIE CHART
data2 = merge2['diagnosis'].value_counts(sort=True)
plt.pie(data2)
labels2 = data2.index.tolist()
plt.pie(data2, labels=labels2)
plt.savefig('second.png')
plt.show()
plt.close()
print('The answer to the 2nd question: pregnancy')

# Height dist by hospital, violin plot
# convert foot to m
query_3 = "hospital == 'sports'"
merge2.loc[merge2.query(query_3).index, 'height'] = merge2.loc[merge2.query(query_3).index, 'height'].apply(lambda x: x / 3.281)
query_3 = "hospital == 'prenatal'"
merge2.loc[merge2.query(query_3).index, 'height'] = merge2.loc[merge2.query(query_3).index, 'height'].apply(lambda x: x / 3.281)

sports_v = merge2.query("hospital == 'sports'")['height'].tolist()
general_v = merge2.query("hospital == 'general'")['height'].tolist()
prenatal_v = merge2.query("hospital == 'prenatal'")['height'].tolist()

fig, axes = plt.subplots()
plt.violinplot([sports_v, general_v, prenatal_v], showmeans=True, showextrema=True, showmedians=True)
axes.set_xticks((1, 2, 3))
axes.set_xticklabels(('sports', 'general', 'prenatal'))

plt.savefig('third.png')
plt.show()
plt.close()

print("The answer to the 3rd question: Two peaks could be because we have women and men in the distribution around this two peaks. The gap is because prenatal hospital work only with babies.")