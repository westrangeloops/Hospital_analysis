from test.tests import EDATest

if __name__ == '__main__':
    EDATest('analysis').run_tests()
